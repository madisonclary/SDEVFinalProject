from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,HttpRequest
from .models import GameSession,DeckCard,PlayerCard,DealerCard
import random

# When the game finishes, call this function and save the game phase as "gameover"
def gameOver(request):
    gameSession = GameSession.objects.all()[0]
    gameSession.gamePhase = 'gameover'
    gameSession.save()
    
    return HttpResponseRedirect('/game')

def game(request):

    # Comprises every moving part of the game and the display
    gameSession = GameSession.objects.all()[0]
    print(str(gameSession.userChips) + ' for me!!!')
    playerHand = PlayerCard.objects.all()
    dealerHand = DealerCard.objects.all()

    currentPlayerScore = getPlayerScore()
    currentDealerScore = getDealerScore()

    # The five win/lose contingencies, makes it easy to figure out whether you get chips
    if gameSession.gamePhase == 'gameover':
        if currentPlayerScore == currentDealerScore:
            gameSession.winner = 'tie'
        elif currentPlayerScore <= 21 and currentDealerScore > 21:
            gameSession.winner = 'player'
        elif currentDealerScore <= 21 and currentPlayerScore > 21:
            gameSession.winner = 'dealer'
        elif currentPlayerScore > currentDealerScore and currentPlayerScore <= 21:
            gameSession.winner = 'player'
        else:
            gameSession.winner = 'dealer'
        
    # Calculate winnings here--really half of this is just for the display
    
        if gameSession.winner == 'dealer':
            gameSession.userChips -= gameSession.currentBet
        elif gameSession.winner == 'player':
            gameSession.winnings = gameSession.currentBet * 2
            gameSession.userChips += gameSession.currentBet

        gameSession.save()

    myDic = {
        'gameSession':gameSession,
        'playerHand':playerHand,
        'dealerHand':dealerHand,
        'playerScore': currentPlayerScore,
        'dealerScore': currentDealerScore,
        }
        
    return render(request, 'blackjack.html', context = myDic)

# Wipes the original EVERYTHING to start over when pushing for a new player
def newplayer(request):
    GameSession.objects.all().delete()
    gameSession = GameSession()
    gameSession.save()    
    return HttpResponseRedirect('/newgame/')

def newgame(request):

    # Wipe the old session!
    DealerCard.objects.all().delete()
    PlayerCard.objects.all().delete()

    # Create new version of the game session in the bet phase
    gameSession = GameSession.objects.all()[0]
    gameSession.gamePhase = 'betting'

    # New deck o' to account for them being removed during gameplay
    DeckCard.objects.all().delete()
    valueArray = ['A','2','3','4','5','6','7','8','9','10','J','Q','K']
    suitArray = ['H','S','C','D']

    for x in valueArray:
        for y in suitArray:
            card = DeckCard(card = x, suit = y)
            card.save()  

    gameSession.save()

    return HttpResponseRedirect('/game')

def bet(request):

    # Uses bet value (amount) and writes it to gameSession
    gameSession = GameSession.objects.all()[0]
    gameSession.currentBet = int(request.POST.get('amount'))
    gameSession.gamePhase = 'playerturn'
    gameSession.save()

    # Actually begins the game by dealing 4 cards, the last of which is hidden
    hit('player')
    hit('dealer')
    hit('player')
    hit('dealer',False)

    return HttpResponseRedirect('/game/')

def stand(request):
    gameSession = GameSession.objects.all()[0]
    gameSession.gamePhase = 'dealerturn'
    gameSession.save()

    for x in DealerCard.objects.all():
        x.revealed = True
        x.save()
        
    # This is if the dealer's cards force them to already stand
    if getDealerScore() >= 17:
        return HttpResponseRedirect('/gameover/')
    else:
        return HttpResponseRedirect('/game/')
        
# When you hit you get a card and it insta-checks if that's going to send you over 21
def pressHit(request):
    hit('player')
    if getPlayerScore() > 21:
        return HttpResponseRedirect('/gameover/')
    else:
        return HttpResponseRedirect('/game/')

def dealerHit(request):
    hit('dealer')
    if getDealerScore() >= 17:
        return HttpResponseRedirect('/gameover/')
    else:
        return HttpResponseRedirect('/game/')

# What actually happens when you pull a card--the card is removed from our database. Left in some console printing from testing
def hit(owner,revealed=True):
    deckSize = DeckCard.objects.all().count()
    cardIndex = random.randint(0,deckSize - 1)

    deckCard = DeckCard.objects.all()[cardIndex]
    print(deckCard.card + ' of ' + deckCard.suit + ' to ' + owner + ', revealed ' + str(revealed))

    if owner == 'dealer':
        dealerCard = DealerCard(card = deckCard.card, suit = deckCard.suit, revealed = revealed)
        dealerCard.save()
    elif owner =='player':
        playerCard = PlayerCard(card = deckCard.card, suit = deckCard.suit)
        playerCard.save()

    DeckCard.objects.all()[cardIndex].delete()
    deckSize = DeckCard.objects.all().count()
    print('Cards left: ' + str(deckSize))

# Run each time you have a chance to display your current score
def getPlayerScore():
    total = 0
    acesInHand = 0
    
    for x in PlayerCard.objects.all():
        if x.card == 'K' or x.card == 'Q' or x.card == 'J':
            total += 10
        elif x.card == 'A':
            total += 11
            acesInHand += 1
        else:
            total += int(x.card)

    # Easy way to work aces into your score--if you go over it just         
    while acesInHand > 0 and total > 21:
        acesInHand -= 1
        total -= 10
             
    return total

# Same dealio as above but with the dealer's score
def getDealerScore():
    total = 0
    acesInHand = 0
    
    for x in DealerCard.objects.all():
        if x.revealed == True:
            if x.card == 'K' or x.card == 'Q' or x.card == 'J':
                total += 10
            elif x.card == 'A':
                total += 11
                acesInHand += 1
            else:
                total += int(x.card)
            
    while acesInHand > 0 and total > 21:
        acesInHand -= 1
        total -= 10
             
    return total