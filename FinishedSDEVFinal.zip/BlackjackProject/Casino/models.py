from django.conf import settings
from django.db import models
from django.utils import timezone

# Code for your "account" in the game, keeps your data until refresh
class GameSession(models.Model):
    userChips = models.IntegerField(default=500)
    gamePhase = models.TextField(max_length=10,default="newgame")
    currentBet = models.IntegerField(default=0)
    winner = models.CharField(max_length=6,default="")
    winnings = models.IntegerField(default=0)

    def __str__(self):
        return self.gamePhase + ' ' + str(self.userChips)
    
    def doesUserHaveChips(self):
        if self.userChips > 0:
            return True
        else:
            return False

# This is the basis for a card from the deck of 52
class DeckCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)

    def __str__(self):
        return self.card + ' of ' + self.suit
    
# This is the framework of a player-held card
class PlayerCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)

    def __str__(self):
        return self.card + ' of ' + self.suit
    
    # Quick way to grab what image is going to be used
    def getSuitImage(self):
        if self.suit == 'S':
            return 'spade.jpg'
        elif self.suit == 'H':
            return 'hearts.jpg'
        elif self.suit == 'D':
            return 'diamond.jpg'
        else:
            return 'club.jpg'

# This is the framework of a dealer-held card
class DealerCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)
    revealed = models.BooleanField(default=True)

    # Quick way to grab what image is going to be used
    def getSuitImage(self):
        if self.suit == 'S':
            return 'spade.jpg'
        elif self.suit == 'H':
            return 'hearts.jpg'
        elif self.suit == 'D':
            return 'diamond.jpg'
        else:
            return 'club.jpg'

    def __str__(self):
        return self.card + ' of ' + self.suit + ',' + str(self.revealed)

# python manage.py sqlmigrate Casino 000x
# python manage.py makemigrations
# python manage.py migrate